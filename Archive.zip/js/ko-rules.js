/**
 *
 *@Author - Eugene Mutai
 *@Twitter - JheneKnights
 *
 * Date: 10/1/13
 * Time: 10:23 AM
 * Description:
 *
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.opensource.org/licenses/gpl-2.0.php
 *
 * Copyright (C) 2013
 * @Version -
 */


//Order form validation
var orderModel = {
    title: ko.observable('').extend({
        required: true,
        minLength: 1,
        pattern: {
            params: /[\w.-]{1,}/, //jhene-knights
            message: "Title of your project cannot be blank."
        }
    }),
    pagesorwords: ko.observable('').extend({
        required: true,
        //digit: true,
        pattern: {
            params: /^(\+)?[0-9.-]{1,}/,
            message: "invalid input, enter only numerical values."
        }
    })
};

//Validation of all the valid fields
orderModel.allisvalid = ko.computed(function() {
    var validation = ko.validatedObservable(orderModel);
    return validation.isValid();
}, orderModel);

//Will take care of the Sidebar login validation
var sideBarModel = {
    emailaddress: ko.observable().extend({
        required: true,
        pattern: {
            params: /^[\w.-]+@[\w.-]+\.[A-Za-z]{2,6}$/, //jhene-knights
            message: "Invalid email address."
        }
    }),
    password: ko.observable().extend({
        required: true,
        minLength: 6
    }),
    allisvalid: ko.computed(function() {
        var validation = ko.validatedObservable(this);
        var bool = validation.isValid();
        return bool;
    }, this)
};

//Validation of the sign up folder
var signUpModel = {
    emailaddress: ko.observable().extend({
        required: true,
        pattern: {
            params: /^[\w.-]+@[\w.-]+\.[A-Za-z]{2,6}$/, //jhene-knights
            message: "Invalid email address."
        }
    }),
    password: ko.observable().extend({
        required: true,
        minLength: 6
    })
};

signUpModel.passwordconfirm = ko.observable().extend({
    required: true,
    equal: signUpModel.password,
    pattern: {
        message: "Passwords does not match!"
    }
});

//to check if everything in the signup form is okay
signUpModel.allisvalid = ko.computed(function() {
    var validation = ko.validatedObservable(signUpModel);
    var bool = validation.isValid();
    return bool;
}, signUpModel);

//Instantiate KO order input bindings
$(document).ready(function() {
    ko.applyBindings(sideBarModel, document.querySelector('.user-login'));
});


